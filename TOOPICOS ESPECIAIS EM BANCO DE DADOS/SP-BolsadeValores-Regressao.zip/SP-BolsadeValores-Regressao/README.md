# Análise de Regressão - Bolsa de Valores
![image](regressao-01.jpg)
